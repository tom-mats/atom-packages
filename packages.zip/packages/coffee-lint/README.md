# coffee-lint

Coffee script linter for Atom editor

* `cmd-ctrl-l` - lint current file
* `cmd-ctrl-shift-l` - toggle results panel

## Configuration
You can change lint options by adding coffeelint.json file in root of project.

![](https://raw.github.com/dotcypress/coffee-lint/master/screenshot.png)
