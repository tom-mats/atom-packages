# Language support for Scala in Atom.

Converted from the [Scala TextMate bundle](https://github.com/mads379/scala.tmbundle)
