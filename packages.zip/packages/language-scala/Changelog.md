# Version 1.1.3
- fix multiline comments (thanks @mcous)
# Version 1.1.2
- Added missing scaladoc `@constructor`
- Fix syntax highlighting for `<-` and `->` operators.
# Version 1.1.1
- Fix `scoped-properties/` -> `settings/` deprecation warning
# Version 1.0.1
- remove sbt grammar, + toogle comments with: https://github.com/jroesch/language-scala/pull/7
- Fix end match regex for import statements: https://github.com/jroesch/language-scala/pull/4
