## 1.5.0 - 2015/5/24 -- LAST RELEASE
- Added deprecation to readme.  Use browser-plus now.

## 1.4.4 - 2015/4/10
- removed duplicate stylesheets folder (thanks @Aarilight)

## 1.4.3 - 2015/4/7
- Fixed crash on page load since atom 0.189.0

## 1.4.2 - 2015/3/3
- fixed deprecations in keymap

## 1.4.1 - 2015/3/3
- fixed setting text in tab

## 1.4.0 - 2015/2/18
- added devdocs.io search

## 1.3.0 - 2015/2/13
- changed auto-reload to ignore cache
- added ctrl-click on reload button to ignore cache
- fixed omnibox url updating when switching tabs

## 1.2.0 - 2015/2/11
- added google search from selected text
- added setting to open all web pages in right pane

## 1.1.8 - 2015/2/10
- auto-reload now uses URL from when auto-reload set

## 1.1.7 - 2015/2/10
- fixed reload of local file

## 1.1.6 - 2015/2/8
- added dev console open/close (bug icon)
- fixed fwd/back buttons

## 1.1.5 - 2015/2/8
- fixed tabs and cut/paste in input forms

## 1.1.4 - 2015/2/8
- restored code commented out in last release for debugging

## 1.1.3 - 2015/2/8
- fixed multiple-pane exceptions

## 1.1.2 - 2015/2/7
- added auto-reload feature

## 1.1.1 - 2015/2/7
- smarter search detection

## 1.1.0 - 2015/2/7
- Favicion appearance (thanks @braver)

## 1.0.0 - 2015/2/6
- switched from iFrame to webview
  - fixed XSS exception
  - ctrl-click links
  - page position persistent on fwd/back
- added google search to omnibar
- webpage loading indicator
- cut activation time in half

## 0.2.3 - 2014/10/16
- Added support for opening URLs
- Supports command-toolbar package for favorites

## 0.2.2 - 2014/10/16

- cleaned up iframe margins and border
- now allows file:// access
- fixed double protocols like:  http://http://xxx.com

## 0.2.1 - 2014/10/13

- Removed test value from omnibar

## 0.2.0 - 2014/10/13

- fixed crashes on pages like github.com
- fixed many same-origin problems
- added correct tab titles, tooltips, and favicons
- http:// is now optional

## 0.1.2 - 2014/10/12

- added color theme to toobar

## 0.1.1 - 2014/10/12

- Fixed package name in readme

## 0.1.0 - First Release -2014/10/11
