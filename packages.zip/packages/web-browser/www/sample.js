
document.write('hello world');
