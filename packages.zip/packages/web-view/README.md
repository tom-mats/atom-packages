# Atom Web View package

Opens a web browser in an editor in Atom.

* `ctrl-shift-G` to open a site
* Use Atom's menu Packages > Web View > Go to page

![Atom Web View](https://raw.github.com/gabceb/atom-web-view/master/atom-web-view.png)
