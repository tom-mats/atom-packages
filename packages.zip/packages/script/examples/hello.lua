function thanks(name)
	print("Thanks for using " .. name .. "!")
end

thanks("atom-script")
