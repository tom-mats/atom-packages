f :: [Integer]
f = [1..10]

main :: IO ()
main = print f
