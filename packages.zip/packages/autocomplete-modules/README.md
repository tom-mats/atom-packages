# Atom autocomplete for modules.
![Current version](https://img.shields.io/apm/v/autocomplete-modules.svg)
![Downloads](https://img.shields.io/apm/dm/autocomplete-modules.svg)
![MIT License](https://img.shields.io/apm/l/autocomplete-modules.svg)

Autocomplete for require/import statements.

![Preview](https://cloud.githubusercontent.com/assets/3505878/7442538/9c1892cc-f11e-11e4-8070-3fa8b79beefc.gif)

License
-------
[MIT](LICENSE)
