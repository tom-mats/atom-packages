## 0.6.2

- blue cursor and selection
- cursor line is slightly highlighted
- search results are highlighted (incl. current one)

## 0.6.1

- highlight line numbers as a function of git status for better visual grepping
- fixed a bug where the marker for removed lines was hidden behing the line cursor
- support for `json`

## 0.6.0

- support for `indent-guide-improved` package
