Pretty JSON
===========

[Atom](http://atom.io/) plugin. Format JSON documents.

![](http://i.imgur.com/Nd4GvtP.gif)

Just select the text to format and select the prettify command. In a JSON file, it formats the whole file.
